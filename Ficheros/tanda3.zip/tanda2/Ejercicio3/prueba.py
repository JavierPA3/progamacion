cadena = "0123456789abcdefghij"

# Mostrar la cadena original
print("Cadena original:", cadena)

# Realizar el cambio en la posición 2 a 18
cadena = cadena[:2] + '' + cadena[18:]

# Mostrar la cadena modificada
print("Cadena modificada:", cadena)