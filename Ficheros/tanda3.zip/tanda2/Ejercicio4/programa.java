/*
 * Este es un comentario de bloque en Java
 * Puedes usar varios renglones para escribir comentarios extensos
 * que explican el propósito del programa, su funcionamiento, autor, fecha, etc.
 */

// Este es un comentario de línea en Java
// Puedes usar comentarios de línea para agregar aclaraciones o notas breves

// Ejemplo de una clase Java
public class MiPrograma {
    public static void main(String[] args) {
        // Comentario en una línea de código
        System.out.println("¡Hola, mundo!"); // Imprime un mensaje en la consola
    }
}