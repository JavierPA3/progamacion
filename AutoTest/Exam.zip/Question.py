"""
Clase question
Atributos:
    Nombre de la pregunta.
    Enunciado
    Elecciones
    Puntuación base de la pregunta.
"""


class Question:

    def __init__(self, question_name: str, question_statement: str, elections: list, question_punctuation: int = 1):
        self.__question_name = question_name
        self.__question_statement = question_statement
        self.__elections = elections
        self.__question_punctuation = question_punctuation

    def obtener_puntuacion(self, option_taken):
        for answer, punctuation in self.__elections:
            if answer == option_taken:
                return punctuation
            elif option_taken == '':
                return 0


    @property
    def question_name(self):
        return self.__question_name

    @property
    def question_statement(self):
        return self.__question_statement

    @property
    def elections(self):
        return self.__elections

    @property
    def question_punctuation(self):
        return self.__question_punctuation
